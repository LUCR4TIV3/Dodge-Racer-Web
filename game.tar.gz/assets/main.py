import pygame
import random
import asyncio

pygame.init()

# Set up game screen
screen = pygame.display.set_mode((900, 650))
pygame.display.set_caption("Dodge Racer")

# Load images
icon = pygame.image.load("sport-car.png")
pygame.display.set_icon(icon)
background = pygame.image.load("game-bg.png")
blurred_background = pygame.transform.smoothscale(background, (900, 650))
PlayerImg = pygame.image.load("main-car.png")
obstacle_img = pygame.image.load("cone.png").convert_alpha()

# Font settings
font = pygame.font.Font(None, 36)
large_font = pygame.font.Font(None, 72)

# Game variables
background_y = 0

PlayerX = 405
PlayerY = 550
player_speed = 4

speed = 4
obstacles = []
min_horizontal_gap = 110

clock = pygame.time.Clock()


def player(x, y):
    screen.blit(PlayerImg, (x, y))


def generate_obstacle():
    max_attempts = 10
    for _ in range(max_attempts):
        x = random.randint(147, 753 - obstacle_img.get_width())
        y = -obstacle_img.get_height()

        too_close = any(abs(x - obs[0]) < min_horizontal_gap for obs in obstacles)
        if not too_close:
            obstacles.append([x, y])
            break


def move_obstacles():
    global speed
    for obstacle in obstacles.copy():
        obstacle[1] += speed
        if obstacle[1] > 650:
            obstacles.remove(obstacle)


def draw_obstacles():
    for obstacle in obstacles:
        screen.blit(obstacle_img, (obstacle[0], obstacle[1]))


def check_collision():
    player_rect = pygame.Rect(
        PlayerX + 15,
        PlayerY + 15,
        PlayerImg.get_width() - 30,
        PlayerImg.get_height() - 30
    )

    for obstacle in obstacles:
        obstacle_rect = pygame.Rect(
            obstacle[0] + 10,
            obstacle[1] + 10,
            obstacle_img.get_width() - 20,
            obstacle_img.get_height() - 20
        )

        if player_rect.colliderect(obstacle_rect):
            return True

    return False


def show_text(text, x, y, font_size=36):
    font_to_use = large_font if font_size > 36 else font
    render = font_to_use.render(text, True, (0, 25, 250))
    screen.blit(render, (x, y))


def reset_game():
    global PlayerX, PlayerY, speed, obstacles, background_y, start_time, speed_increase_time
    PlayerX = 405
    PlayerY = 550
    speed = 4
    obstacles.clear()
    background_y = 0
    start_time = pygame.time.get_ticks()
    speed_increase_time = start_time


start_time = pygame.time.get_ticks()
speed_increase_time = start_time


async def main():
    global PlayerX, PlayerY, speed, background_y, speed_increase_time

    running = True
    game_state = "menu"
    final_score = 0

    while running:
        screen.fill((0, 0, 0))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if game_state == "menu":
                if event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
                    reset_game()
                    game_state = "playing"

            elif game_state == "game_over":
                if event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
                    reset_game()
                    game_state = "playing"

        if game_state == "menu":
            screen.blit(blurred_background, (0, 0))
            show_text("Dodge Racer", 300, 200, 72)
            show_text("Press ENTER to Start", 200, 300, 48)

        elif game_state == "playing":
            keys = pygame.key.get_pressed()
            player_dx = (keys[pygame.K_RIGHT] - keys[pygame.K_LEFT]) * player_speed
            player_dy = (keys[pygame.K_DOWN] - keys[pygame.K_UP]) * player_speed

            PlayerX += player_dx
            PlayerY += player_dy

            PlayerX = max(147, min(753 - PlayerImg.get_width(), PlayerX))
            PlayerY = max(0, min(650 - PlayerImg.get_height(), PlayerY))

            if random.random() < 0.05:
                generate_obstacle()
                if random.random() < 0.25:
                    generate_obstacle()

            move_obstacles()

            elapsed_time = (pygame.time.get_ticks() - start_time) // 1000

            if elapsed_time > 0 and elapsed_time % 10 == 0 and pygame.time.get_ticks() - speed_increase_time >= 10000:
                speed += 0.5
                speed_increase_time = pygame.time.get_ticks()

            screen.blit(background, (0, background_y))
            screen.blit(background, (0, background_y - 650))

            draw_obstacles()
            player(PlayerX, PlayerY)
            show_text(f"Score: {elapsed_time}", 750, 10)

            if check_collision():
                final_score = elapsed_time
                game_state = "game_over"

            background_y += speed
            if background_y >= 650:
                background_y = 0

        elif game_state == "game_over":
            screen.blit(blurred_background, (0, 0))
            show_text("Game Over!", 320, 200, 72)
            show_text(f"Your score was: {final_score}", 250, 300, 48)
            show_text("Press ENTER to Play Again", 120, 400, 48)

        pygame.display.update()
        clock.tick(60)
        await asyncio.sleep(0)

    pygame.quit()


asyncio.run(main())